const INSTALL_DISMISSED_KEY = 'fieldRef.installDismissed'
const OFFLINE_READY_KEY = 'fieldRef.offlineReadySeen'

let deferredPrompt = null

function byId(id) {
  return document.getElementById(id)
}

function setConnectionState() {
  const dot = byId('pwaConnectionDot')
  const text = byId('pwaConnectionText')
  if (!dot || !text) return

  if (navigator.onLine) {
    dot.className = 'h-2 w-2 rounded-full bg-emerald-300'
    text.textContent = 'Online'
  } else {
    dot.className = 'h-2 w-2 rounded-full bg-amber-300'
    text.textContent = 'Offline'
  }
}

function showBanner(message, type = 'info') {
  const el = byId('pwaBanner')
  const text = byId('pwaBannerText')
  if (!el || !text) return

  text.textContent = message

  el.className =
    type === 'success'
      ? 'mt-4 rounded-2xl border border-emerald-400/20 bg-emerald-500/10 px-4 py-3 text-sm text-emerald-200'
      : type === 'warn'
        ? 'mt-4 rounded-2xl border border-amber-400/20 bg-amber-500/10 px-4 py-3 text-sm text-amber-100'
        : 'mt-4 rounded-2xl border border-cyan-400/20 bg-cyan-500/10 px-4 py-3 text-sm text-cyan-100'

  el.classList.remove('hidden')
}

function hideBanner() {
  const el = byId('pwaBanner')
  if (!el) return
  el.classList.add('hidden')
}

function bindBannerDismiss() {
  byId('dismissPwaBannerBtn')?.addEventListener('click', () => {
    hideBanner()
    localStorage.setItem(INSTALL_DISMISSED_KEY, '1')
  })
}

function bindInstallButton() {
  byId('installAppBtn')?.addEventListener('click', async () => {
    if (!deferredPrompt) {
      showBanner(
        'Install from your browser menu if the install prompt is not available yet.',
        'warn'
      )
      return
    }

    deferredPrompt.prompt()
    await deferredPrompt.userChoice
    deferredPrompt = null
    hideInstallButton()
  })
}

function hideInstallButton() {
  byId('installAppBtn')?.classList.add('hidden')
}

function maybeShowOfflineReady() {
  if (localStorage.getItem(OFFLINE_READY_KEY) === '1') return

  showBanner(
    'Offline mode ready.',
    'success'
  )
  localStorage.setItem(OFFLINE_READY_KEY, '1')
}

function registerServiceWorker() {
  if (!('serviceWorker' in navigator)) return

  window.addEventListener('load', async () => {
    try {
      await navigator.serviceWorker.register('/sw.js')
      maybeShowOfflineReady()
    } catch (err) {
      console.error('SW registration failed:', err)
    }
  })
}

window.addEventListener('beforeinstallprompt', (event) => {
  event.preventDefault()
  deferredPrompt = event

  if (localStorage.getItem(INSTALL_DISMISSED_KEY) !== '1') {
    byId('installAppBtn')?.classList.remove('hidden')
  }
})

window.addEventListener('appinstalled', () => {
  hideInstallButton()
  showBanner('App installed successfully.', 'success')
})

window.addEventListener('online', setConnectionState)
window.addEventListener('offline', setConnectionState)

bindBannerDismiss()
bindInstallButton()
setConnectionState()
registerServiceWorker()