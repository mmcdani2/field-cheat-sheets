import {
  byId,
  clearStatus,
  createWizard,
  showError,
  showStatus,
} from "../core.js";
import {
  flushQueue,
  getQueueCount,
  queueSubmission,
  updateQueuedSubmission,
} from "../offline-queue.js";

const WEB_APP_URL = "PASTE_YOUR_GOOGLE_APPS_SCRIPT_WEB_APP_URL_HERE";

const MODULE_KEY = "spray-foam-job-log";
const DRAFT_KEY = "fieldRef.sprayFoamJobLogDraft";
const STEP_KEY = "fieldRef.sprayFoamJobLogStep";
const EDIT_QUEUE_KEY = "fieldRef.sprayFoamJobLogEditQueueId";

const steps = Array.from(document.querySelectorAll(".wizard-step"));
const progressEl = byId("wizardProgress");
const stepTextEl = byId("wizardStepText");
const nextBtn = byId("nextBtn");
const backBtn = byId("backBtn");
const errorBox = byId("wizardError");
const statusBox = byId("wizardStatus");
const formEl = byId("sprayFoamWizardForm");
const reviewList = byId("reviewList");
const queueIndicator = byId("queueIndicator");
const queueIndicatorText = byId("queueIndicatorText");
const viewQueuedBtn = byId("viewQueuedBtn");
const editQueueBanner = byId("editQueueBanner");

let statusTimer = null;

function getFieldValue(id) {
  return byId(id)?.value?.trim() || "";
}

function getNum(id) {
  const raw = byId(id)?.value ?? "";
  const n = Number.parseFloat(raw);
  return Number.isFinite(n) ? n : 0;
}

function generateSubmissionId() {
  if (window.crypto?.randomUUID) {
    return window.crypto.randomUUID();
  }

  return `sf_${Date.now()}_${Math.random().toString(36).slice(2, 10)}`;
}

function getPayload() {
  const existingDraft = JSON.parse(localStorage.getItem(DRAFT_KEY) || "{}");
  const submissionId = existingDraft.submissionId || generateSubmissionId();

  return {
    submissionId,
    techName: getFieldValue("sfTech"),
    helperCrew: getFieldValue("sfHelperCrew"),
    jobNumber: getFieldValue("sfJobNumber"),
    customerName: getFieldValue("sfCustomerName"),
    address: getFieldValue("sfAddress"),
    city: getFieldValue("sfCity"),
    state: getFieldValue("sfState").toUpperCase(),
    foamType: getFieldValue("sfFoamType"),
    areaSprayed: getFieldValue("sfAreaSprayed"),
    targetThickness: getNum("sfTargetThickness"),
    estimatedBoardFeet: getNum("sfEstimatedBoardFeet"),
    materialSetUsed: getFieldValue("sfMaterialSetUsed"),
    ambientTemp: getNum("sfAmbientTemp"),
    substrateTemp: getNum("sfSubstrateTemp"),
    startTime: getFieldValue("sfStartTime"),
    endTime: getFieldValue("sfEndTime"),
    rigNotes: getFieldValue("sfRigNotes"),
    issuesEncountered: getFieldValue("sfIssuesEncountered"),
    jobNotes: getFieldValue("sfJobNotes"),
  };
}

function getDraftData() {
  return {
    submissionId:
      JSON.parse(localStorage.getItem(DRAFT_KEY) || "{}")?.submissionId || "",
    sfTech: byId("sfTech")?.value ?? "",
    sfHelperCrew: byId("sfHelperCrew")?.value ?? "",
    sfJobNumber: byId("sfJobNumber")?.value ?? "",
    sfCustomerName: byId("sfCustomerName")?.value ?? "",
    sfAddress: byId("sfAddress")?.value ?? "",
    sfCity: byId("sfCity")?.value ?? "",
    sfState: byId("sfState")?.value ?? "",
    sfFoamType: byId("sfFoamType")?.value ?? "",
    sfAreaSprayed: byId("sfAreaSprayed")?.value ?? "",
    sfTargetThickness: byId("sfTargetThickness")?.value ?? "",
    sfEstimatedBoardFeet: byId("sfEstimatedBoardFeet")?.value ?? "",
    sfMaterialSetUsed: byId("sfMaterialSetUsed")?.value ?? "",
    sfAmbientTemp: byId("sfAmbientTemp")?.value ?? "",
    sfSubstrateTemp: byId("sfSubstrateTemp")?.value ?? "",
    sfStartTime: byId("sfStartTime")?.value ?? "",
    sfEndTime: byId("sfEndTime")?.value ?? "",
    sfRigNotes: byId("sfRigNotes")?.value ?? "",
    sfIssuesEncountered: byId("sfIssuesEncountered")?.value ?? "",
    sfJobNotes: byId("sfJobNotes")?.value ?? "",
  };
}

function saveDraft() {
  localStorage.setItem(DRAFT_KEY, JSON.stringify(getDraftData()));
}

function loadDraft() {
  const raw = localStorage.getItem(DRAFT_KEY);
  if (!raw) return;

  try {
    const draft = JSON.parse(raw);

    Object.entries(draft).forEach(([id, value]) => {
      const el = byId(id);
      if (!el) return;
      el.value = value ?? "";
    });
  } catch (err) {
    console.error("Failed to load spray foam draft:", err);
  }
}

function clearDraft() {
  localStorage.removeItem(DRAFT_KEY);
}

function saveCurrentStep(stepIndex) {
  localStorage.setItem(STEP_KEY, String(stepIndex));
}

function loadCurrentStep() {
  const raw = localStorage.getItem(STEP_KEY);
  const step = Number.parseInt(raw ?? "0", 10);

  if (!Number.isInteger(step)) return 0;
  if (step < 0) return 0;
  if (step > steps.length - 1) return 0;

  return step;
}

function clearCurrentStep() {
  localStorage.removeItem(STEP_KEY);
}

function getEditingQueueId() {
  const raw = localStorage.getItem(EDIT_QUEUE_KEY);
  const id = Number.parseInt(raw ?? "", 10);
  return Number.isInteger(id) && id > 0 ? id : null;
}

function clearEditingQueueId() {
  localStorage.removeItem(EDIT_QUEUE_KEY);
}

function syncEditModeUi() {
  const editingId = getEditingQueueId();

  if (editQueueBanner) {
    editQueueBanner.classList.toggle("hidden", !editingId);
  }

  if (nextBtn && wizard.getCurrentStep() === steps.length - 1) {
    nextBtn.textContent = editingId ? "Save Changes" : "Submit Log";
  }
}

function bindDraftAutosave() {
  const ids = [
    "sfTech",
    "sfHelperCrew",
    "sfJobNumber",
    "sfCustomerName",
    "sfAddress",
    "sfCity",
    "sfState",
    "sfFoamType",
    "sfAreaSprayed",
    "sfTargetThickness",
    "sfEstimatedBoardFeet",
    "sfMaterialSetUsed",
    "sfAmbientTemp",
    "sfSubstrateTemp",
    "sfStartTime",
    "sfEndTime",
    "sfRigNotes",
    "sfIssuesEncountered",
    "sfJobNotes",
  ];

  ids.forEach((id) => {
    const el = byId(id);
    if (!el) return;
    el.addEventListener("input", saveDraft);
    el.addEventListener("change", saveDraft);
  });
}

function bindFoamTypeButtons() {
  const hiddenInput = byId("sfFoamType");
  const buttons = Array.from(document.querySelectorAll(".foamTypeBtn"));

  if (!hiddenInput || !buttons.length) return;

  function render() {
    buttons.forEach((btn) => {
      const active = btn.dataset.value === hiddenInput.value;

      btn.className = active
        ? "foamTypeBtn rounded-2xl border border-amber-400/30 bg-amber-500/15 px-4 py-4 text-base font-bold text-amber-200 transition active:scale-[0.98]"
        : "foamTypeBtn rounded-2xl border border-white/10 bg-neutral-900 px-4 py-4 text-base font-bold text-white transition active:scale-[0.98]";
    });
  }

  buttons.forEach((btn) => {
    btn.addEventListener("click", () => {
      hiddenInput.value = btn.dataset.value || "";
      saveDraft();
      render();
    });
  });

  render();
}

function showStepError(message, id) {
  showError(errorBox, message);
  byId(id)?.focus();
  return false;
}

function showTimedStatus(message, ok = true, ms = 4000) {
  if (statusTimer) {
    clearTimeout(statusTimer);
    statusTimer = null;
  }

  showStatus(statusBox, message, ok);

  statusTimer = setTimeout(() => {
    clearStatus(statusBox);
    statusTimer = null;
  }, ms);
}

function validateStep(stepIndex) {
  if (stepIndex === 0 && !getFieldValue("sfTech")) {
    return showStepError("Tech / Sprayer Name is required.", "sfTech");
  }

  if (stepIndex === 2 && !getFieldValue("sfJobNumber")) {
    return showStepError("Job Number is required.", "sfJobNumber");
  }

  if (stepIndex === 3 && !getFieldValue("sfCustomerName")) {
    return showStepError("Customer Name is required.", "sfCustomerName");
  }

  if (stepIndex === 4) {
    if (!getFieldValue("sfAddress")) {
      return showStepError("Address is required.", "sfAddress");
    }
    if (!getFieldValue("sfCity")) {
      return showStepError("City is required.", "sfCity");
    }
    if (!getFieldValue("sfState")) {
      return showStepError("State is required.", "sfState");
    }
  }

  if (stepIndex === 5 && !getFieldValue("sfFoamType")) {
    return showStepError("Foam Type is required.", "sfFoamType");
  }

  if (stepIndex === 6 && !getFieldValue("sfAreaSprayed")) {
    return showStepError("Area Sprayed is required.", "sfAreaSprayed");
  }

  if (stepIndex === 7) {
    if (getNum("sfTargetThickness") <= 0) {
      return showStepError(
        "Target Thickness must be greater than 0.",
        "sfTargetThickness",
      );
    }

    if (getNum("sfEstimatedBoardFeet") <= 0) {
      return showStepError(
        "Estimated Board Feet must be greater than 0.",
        "sfEstimatedBoardFeet",
      );
    }
  }

  if (stepIndex === 8 && !getFieldValue("sfMaterialSetUsed")) {
    return showStepError("Material Set Used is required.", "sfMaterialSetUsed");
  }

  if (stepIndex === 9) {
    if (!byId("sfAmbientTemp")?.value) {
      return showStepError("Ambient Temperature is required.", "sfAmbientTemp");
    }

    if (!byId("sfSubstrateTemp")?.value) {
      return showStepError(
        "Substrate Temperature is required.",
        "sfSubstrateTemp",
      );
    }
  }

  if (stepIndex === 10) {
    if (!getFieldValue("sfStartTime")) {
      return showStepError("Start Time is required.", "sfStartTime");
    }

    if (!getFieldValue("sfEndTime")) {
      return showStepError("End Time is required.", "sfEndTime");
    }
  }

  return true;
}

function renderReview() {
  if (!reviewList) return;

  const payload = getPayload();

  const items = [
    ["Tech", payload.techName],
    ["Helper / Crew", payload.helperCrew || "—"],
    ["Job #", payload.jobNumber],
    ["Customer", payload.customerName],
    ["Address", `${payload.address}, ${payload.city}, ${payload.state}`],
    ["Foam Type", payload.foamType],
    ["Area Sprayed", payload.areaSprayed],
    ["Target Thickness", `${payload.targetThickness} in`],
    ["Est. Board Feet", String(payload.estimatedBoardFeet)],
    ["Material Set", payload.materialSetUsed],
    ["Ambient Temp", `${payload.ambientTemp} °F`],
    ["Substrate Temp", `${payload.substrateTemp} °F`],
    ["Start / End", `${payload.startTime} → ${payload.endTime}`],
    ["Rig Notes", payload.rigNotes || "—"],
    ["Issues", payload.issuesEncountered || "—"],
    ["Job Notes", payload.jobNotes || "—"],
  ];

  reviewList.innerHTML = items
    .map(
      ([label, value]) => `
        <div class="rounded-xl border border-white/10 bg-neutral-900/70 px-4 py-3">
          <div class="text-xs uppercase tracking-wide text-white/45">${label}</div>
          <div class="mt-1 text-sm font-medium text-white">${value}</div>
        </div>
      `,
    )
    .join("");
}

function setQueueIndicator(count) {
  if (!queueIndicator || !queueIndicatorText) return;

  if (count > 0) {
    queueIndicator.classList.remove("hidden");
    queueIndicatorText.textContent = `${count} queued for sync`;
    return;
  }

  queueIndicator.classList.add("hidden");
  queueIndicatorText.textContent = "";
}

viewQueuedBtn?.addEventListener("click", () => {
  showTimedStatus("Queued spray foam log view is not wired yet.", false);
});

async function updateQueueStatus() {
  const count = await getQueueCount(MODULE_KEY);
  setQueueIndicator(count);
}

async function postPayload(payload, endpoint = WEB_APP_URL) {
  const res = await fetch(endpoint, {
    method: "POST",
    headers: { "Content-Type": "text/plain;charset=utf-8" },
    body: JSON.stringify(payload),
  });

  const data = await res.json().catch(() => ({}));

  if (!res.ok || data.ok !== true) {
    throw new Error(data.error || `HTTP ${res.status}`);
  }

  return data;
}

async function tryFlushQueue() {
  const result = await flushQueue({
    module: MODULE_KEY,
    submitFn: async (item) => {
      await postPayload(item.payload, item.endpoint);
    },
  });

  if (!result.skipped && result.sent > 0) {
    showTimedStatus(
      `${result.sent} queued submission${result.sent === 1 ? "" : "s"} synced successfully.`,
    );
  }

  await updateQueueStatus();
}

function resetFormUi() {
  formEl?.reset();
  clearDraft();
  clearCurrentStep();
  clearEditingQueueId();
  bindFoamTypeButtons();
  wizard.setCurrentStep(0);
}

async function submitLog() {
  const payload = getPayload();
  const editingQueueId = getEditingQueueId();

  clearStatus(statusBox);
  nextBtn.disabled = true;
  nextBtn.textContent = "Submitting...";

  if (editingQueueId) {
    try {
      await updateQueuedSubmission(editingQueueId, {
        payload,
        status: "queued",
        lastError: "",
        retryCount: 0,
      });

      resetFormUi();
      await updateQueueStatus();
      showTimedStatus("Queued spray foam log updated.");
      return;
    } catch (err) {
      showStatus(
        statusBox,
        `Failed to save queued log changes. (${String(err)})`,
        false,
      );
      nextBtn.disabled = false;
      nextBtn.textContent = "Next";
      return;
    }
  }

  try {
    if (!navigator.onLine) {
      await queueSubmission({
        module: MODULE_KEY,
        endpoint: WEB_APP_URL,
        payload,
      });

      showStatus(
        statusBox,
        "No connection. Log saved locally and will sync when online.",
      );

      resetFormUi();
      await updateQueueStatus();
      return;
    }

    await postPayload(payload);

    showTimedStatus("Log submitted successfully.");
    resetFormUi();
    await tryFlushQueue();
  } catch (err) {
    await queueSubmission({
      module: MODULE_KEY,
      endpoint: WEB_APP_URL,
      payload,
    });

    showStatus(
      statusBox,
      `Submit failed live. Log saved locally and will retry when online. (${String(err)})`,
      false,
    );

    resetFormUi();
    await updateQueueStatus();
  } finally {
    nextBtn.disabled = false;
    nextBtn.textContent = "Next";
  }
}

const wizard = createWizard({
  steps,
  progressEl,
  stepTextEl,
  nextBtn,
  backBtn,
  errorBox,
  onRenderStep: (stepIndex) => {
    saveCurrentStep(stepIndex);

    if (stepIndex === steps.length - 1) {
      renderReview();
    }

    syncEditModeUi();
  },
  onValidateStep: validateStep,
  onSubmit: submitLog,
  submitLabel: "Submit Log",
  nextLabel: "Next",
});

window.addEventListener("online", () => {
  tryFlushQueue();
});

loadDraft();
bindDraftAutosave();
bindFoamTypeButtons();
wizard.setCurrentStep(loadCurrentStep());
syncEditModeUi();
updateQueueStatus();
tryFlushQueue();
